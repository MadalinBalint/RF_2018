package ro.usv.rf;

public class MainClass {
    public static void main(String[] args) {
        final String PATH = "D:\\Facultate\\Facultate Calculatoare anul IV\\RF\\Laborator\\Laborator_08\\";

        double[][] learningSet = null;
        try {
            learningSet = FileUtils.readLearningSetFromFile(PATH + "in.txt");
            int numberOfPatterns = learningSet.length;
            int numberOfFeatures = learningSet[0].length;
            System.out.println(String.format("The learning set has %s patters and %s features", numberOfPatterns, numberOfFeatures));
            int[] clase = ClassificationUtils.classifySet(learningSet, 3, numberOfFeatures);
            for (int c : clase) {
                System.out.println("Class: " + (c + 1));
            }
        } catch (USVInputFileCustomException e) {
            System.out.println(e.getMessage());
        } finally {
            System.out.println("Finished learning set operations\n");
        }
    }
}