package ro.usv.rf;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

public class MainClass {
    private static final String PATH = "D:\\Facultate\\Facultate Calculatoare anul IV\\RF\\Laborator\\Laborator_06\\src\\";

    public static void main(String[] args) {
        ArrayList<Grade> grades = null;
        HashMap<Double, String> learningSet;

        try {
            grades = FileUtils.readLearningSetFromFile(PATH + "gradesClasses.txt");
            learningSet = FileUtils.getUniqueLearningSet(grades);
            int u = grades.size();
            int p = learningSet.size();
            System.out.println(String.format("The learning set has %s patterns, %s unique patterns", u, p));
        } catch (USVInputFileCustomException e) {
            System.out.println(e.getMessage());
        } finally {
            System.out.println("Finished learning set operations");
        }

        List<Double> test_grades = Arrays.asList(3.80, 5.75, 6.25, 7.25, 8.5);
        List<Integer> k_values = Arrays.asList(1, 3, 5, 7, 9, 13, 15, 17);

        for (double g : test_grades) {
            System.out.println("\nGrade "+g+":");
            for (int k : k_values) {
                System.out.println("Searching " + k + " nearest neighbours:");

                ArrayList<Grade> neighbors = FileUtils.nearestNeighbors(grades, g, k);
                System.out.println(neighbors);

                HashMap<String, Integer> classes = FileUtils.classCounter(neighbors);
                System.out.println("Class = "+ FileUtils.getGradeClass(classes)+"\n");
            }
        }
    }
}