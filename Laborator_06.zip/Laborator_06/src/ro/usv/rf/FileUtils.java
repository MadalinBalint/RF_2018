package ro.usv.rf;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Stream;

public class FileUtils {
    private static final String inputFileValuesSeparator = " ";
    private static final String outputFileValuesSeparator = ",";

    protected static ArrayList<Grade> readLearningSetFromFile(String fileName) throws USVInputFileCustomException {
        ArrayList<Grade> grades = new ArrayList<>();

        try {
            Stream<String> stream = Files.lines(Paths.get(fileName));
            Iterator<String> iterator = stream.iterator();

            while (iterator.hasNext()) {
                String s = iterator.next();

                String[] values = convertLineToLearningSetRow(s);
                if (values.length == 2) {
                    Grade grade = new Grade(Double.valueOf(values[0]), values[1]);
                    grades.add(grade);
                }
            }
        } catch (FileNotFoundException fnfe) {
            throw new USVInputFileCustomException(" We cannot find the specified file on the computer");
        } catch (IOException ioe) {
            throw new USVInputFileCustomException(" We encountered some errors while trying to read the specified file: " + ioe.getMessage());
        } catch (Exception e) {
            throw new USVInputFileCustomException(" Other errors: " + e.getMessage());
        }
        return grades;
    }

    private static String[] convertLineToLearningSetRow(String line) {
        String[] learningSetRow = line.split(",");

        return learningSetRow;
    }

    protected static HashMap<Double, String> getUniqueLearningSet(ArrayList<Grade> grades) {
        HashMap<Double, String> learningSet = new HashMap<>();

        for (Grade grade : grades) {
            learningSet.put(grade.grade_value, grade.grade_class);
        }

        return learningSet;
    }

    public static double euclideanDistance(double a, double b) {
        return Math.abs(a - b);
    }

    protected static ArrayList<Grade> nearestNeighbors(ArrayList<Grade> grades, double grade, int k) {
        ArrayList<Grade> neighbors = new ArrayList<>();
        ArrayList<Double> diffs = new ArrayList<>();
        ArrayList<Double> sortedDiffs = new ArrayList<>();

        ArrayList<NewGrade> neighborsDiff = new ArrayList<>();

        for (Grade g : grades) {
            neighborsDiff.add(new NewGrade(g, euclideanDistance(grade, g.grade_value)));
            diffs.add(euclideanDistance(grade, g.grade_value));
            sortedDiffs.add(euclideanDistance(grade, g.grade_value));
        }

        Collections.sort(sortedDiffs);

        for (int i = 0; i < k; i++) {
            double diff = sortedDiffs.get(i);
            //int index = diffs.indexOf(sortedDiffs.get(i));

            for (NewGrade n : neighborsDiff) {
                if (n.diff == diff && !n.marked) {
                    neighbors.add(n.grade);
                    n.marked = true;
                    break;
                }
            }
        }

        return neighbors;
    }

    protected static HashMap<String, Integer> classCounter(ArrayList<Grade> neighbors) {
        HashMap<String, Integer> counters = new HashMap<>();

        for (Grade g : neighbors) {
            if (counters.containsKey(g.grade_class)) {
                int val = counters.get(g.grade_class);
                val = val + 1;
                counters.put(g.grade_class, val);
            } else counters.put(g.grade_class, 1);
        }

        return counters;
    }

    protected static String getGradeClass(HashMap<String, Integer> counters) {
        String s = "";
        int max = 0;

        Iterator it = counters.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            if ((int) pair.getValue() > max) max = (int) pair.getValue();
            System.out.println(pair.getKey() + " = " + pair.getValue());
            //it.remove(); // avoids a ConcurrentModificationException
        }

        it = counters.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry pair = (Map.Entry) it.next();
            int val = (int) pair.getValue();
            if (val == max) return (String) pair.getKey();

        }

        return "";
    }

    protected static void writeLearningSetToFile(String fileName, double[][] normalizedSet) {
        // first create the byte array to be written
        StringBuilder stringBuilder = new StringBuilder();
        for (int n = 0; n < normalizedSet.length; n++) //for each row
        {
            //for each column
            for (int p = 0; p < normalizedSet[n].length; p++) {
                //append to the output string
                stringBuilder.append(normalizedSet[n][p] + "");
                //if this is not the last row element
                if (p < normalizedSet[n].length - 1) {
                    //then add separator
                    stringBuilder.append(outputFileValuesSeparator);
                }
            }
            //append new line at the end of the row
            stringBuilder.append("\n");
        }
        try {
            Files.write(Paths.get(fileName), stringBuilder.toString().getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
