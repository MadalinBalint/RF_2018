package ro.usv.rf;

public class NewGrade {
    public Grade grade;
    public double diff;
    public boolean marked;

    public NewGrade(Grade grade, double diff) {
        this.grade = grade;
        this.diff = diff;
        marked = false;
    }
}
