package ro.usv.rf;

public class Grade {
    public double grade_value;
    public String  grade_class;

    public Grade(double grade_value, String grade_class) {
        this.grade_value = grade_value;
        this.grade_class = grade_class;
    }

    @Override
    public String toString() {
        return "Grade{" +
                "value=" + grade_value +
                ", class='" + grade_class + '\'' +
                '}';
    }
}
