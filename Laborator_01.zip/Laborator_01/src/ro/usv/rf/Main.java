package ro.usv.rf;

import java.util.Arrays;

public class Main {
    private static String path = "d:/Facultate/Facultate Calculatoare anul IV/RF/Laborator/Laborator_01/src/";

    private static double[][] normalizeLearningSet(double[][] learningSet) {
        int rows = learningSet.length;
        int columns = learningSet[0].length;

        double[][] normalizedLearningSet = new double[rows][columns];
        double[] min = new double[columns];
        double[] max = new double[columns];

        System.out.println("Dimensiuni: i=" + rows + ", j=" + columns);

        for (int i = 0; i < columns; i++) {
            min[i] = learningSet[0][i];
            max[i] = learningSet[0][i];
        }

        for (int j = 0; j < columns; j++) {
            for (int i = 0; i < rows; i++) {
                if (learningSet[i][j] < min[j]) min[j] = learningSet[i][j];
                if (learningSet[i][j] > max[j]) max[j] = learningSet[i][j];

            }
        }

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                normalizedLearningSet[i][j] = (learningSet[i][j] - min[j]) / (max[j] - min[j]);
            }
        }

        System.out.println("Min = " + Arrays.toString(min));
        System.out.println("Max = " + Arrays.toString(max));


        return normalizedLearningSet;
    }

    public static void main(String[] args) {
        double[][] learningSet = FileUtils.readLearningSetFromFile(path + "in.txt");
        FileUtils.writeLearningSetToFile(path + "out.csv", normalizeLearningSet(learningSet));
    }
}