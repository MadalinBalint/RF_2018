package ro.usv.rf;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FileUtils {
    private static final String inputFileValuesSeparator = " ";
    private static final String outputFileValuesSeparator = ", ";

    protected static double[][] readLearningSetFromFile(String fileName) {
        List<ArrayList<Double>> learningSet = new ArrayList<ArrayList<Double>>();

        try (Stream<String> stream = Files.lines(Paths.get(fileName))) {
            learningSet = stream.map(FileUtils::convertLineToLearningSetRow).collect(Collectors.toList());
        } catch (IOException e) {
            System.out.println("Eroare readLearningSetFromFile:");
            e.printStackTrace();
        }

        return convertToBiDimensionalArray(learningSet);
    }

    private static double[][] convertToBiDimensionalArray(List<ArrayList<Double>> learningSet) {
        double[][] learningSetArray = new double[learningSet.size()][];
        for (int n = 0; n < learningSet.size(); n++) {
            ArrayList<Double> rowListEntry = learningSet.get(n);

            double[] rowArray = new double[learningSet.get(n).size()];
            for (int p = 0; p < learningSet.get(n).size(); p++) {
                rowArray[p] = rowListEntry.get(p);
            }
            learningSetArray[n] = rowArray;
        }
        return learningSetArray;
    }

    private static ArrayList<Double> convertLineToLearningSetRow(String line) {
        ArrayList<Double> learningSetRow = new ArrayList<Double>();

        String[] stringValues = line.split(inputFileValuesSeparator);
        for (int p = 0; p < stringValues.length; p++) {
            learningSetRow.add(Double.valueOf(stringValues[p]));
        }
        return learningSetRow;
    }

    protected static void writeLearningSetToFile(String fileName, double[][] normalizedSet) {
        StringBuilder stringBuilder = new StringBuilder();

        if (normalizedSet == null) {
            System.out.println("Eroare writeLearningSetToFile: null value");
            return;
        }

        for (int n = 0; n < normalizedSet.length; n++) {
            for (int p = 0; p < normalizedSet[n].length; p++) {
                stringBuilder.append(/*normalizedSet[n][p] + ""*/String.format("%.2f", normalizedSet[n][p]));
                if (p < normalizedSet[n].length - 1) {
                    stringBuilder.append(outputFileValuesSeparator);
                }
            }
            stringBuilder.append("\n");
        }

        try {
            Files.write(Paths.get(fileName), stringBuilder.toString().getBytes());
        } catch (IOException e)

        {
            e.printStackTrace();
        }
    }
}