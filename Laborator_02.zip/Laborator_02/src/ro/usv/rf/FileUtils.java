package ro.usv.rf;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FileUtils {
    private static final String inputFileValuesSeparator = " ";
    private static final String outputFileValuesSeparator = ", ";

    protected static double[][] readLearningSetFromFile(String fileName) {
        //Start with an ArrayList<ArrayList<Double>>
        List<ArrayList<Double>> learningSet = new ArrayList<ArrayList<Double>>();

        // read file into stream, try-with-resources
        try (Stream<String> stream = Files.lines(Paths.get(fileName))) {
            learningSet = stream.map(FileUtils::convertLineToLearningSetRow).collect(Collectors.toList());
        } catch (IOException e) {
            e.printStackTrace();
        }

        //  convert ArrayList<ArrayList<Double>> to double[][] for performance
        return convertToBiDimensionalArray(learningSet);
    }

    private static double[][] convertToBiDimensionalArray(List<ArrayList<Double>> learningSet) {
        int size = learningSet.size();

        double[][] learningSetArray = new double[size][];

        for (int n = 0; n < size; n++) {
            ArrayList<Double> rowListEntry = learningSet.get(n);

            // get each row double values
            int size2 = learningSet.get(n).size();
            double[] rowArray = new double[size2];

            for (int p = 0; p < size2; p++) {
                rowArray[p] = rowListEntry.get(p);
            }
            learningSetArray[n] = rowArray;

        }
        return learningSetArray;
    }

    private static ArrayList<Double> convertLineToLearningSetRow(String line) {
        ArrayList<Double> learningSetRow = new ArrayList<>();
        String[] stringValues = line.split(inputFileValuesSeparator);

        //we need to convert from string to double
        for (int p = 0; p < stringValues.length; p++) {
            learningSetRow.add(Double.valueOf(stringValues[p]));
        }
        return learningSetRow;
    }

    protected static void writeLearningSetToFile(String fileName, double[][] normalizedSet) {
        // first create the byte array to be written
        StringBuilder stringBuilder = new StringBuilder();

        int size = normalizedSet.length;

        for (int n = 0; n < size; n++) //for each row
        {
            int size2 = normalizedSet[n].length;

            // for each column
            for (int p = 0; p < size2; p++) {
                // append to the output string
                stringBuilder.append(String.format("%.4f", normalizedSet[n][p]));

                // if this is not the last row element
                if (p < size2 - 1) {
                    //then add separator
                    stringBuilder.append(outputFileValuesSeparator);
                }
            }

            //append new line at the end of the row
            stringBuilder.append("\n");
        }
        try {
            Files.write(Paths.get(fileName), stringBuilder.toString().getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}